a) To get the results in a csv file, run the command:
    python run_query.py

b) To print the result over terminal itself, run the command:
get-papers-list "cancer immunotherapy"

Instead of "cancer immunotherapy", you can type any other query argument as well.

Also, NOTE THAT THIS IS NOT THE ACTUAL README FILE, THE ACTUAL README FILE IS INCLUDED IN THE COMPRESEED FOLDER ATTACHED IN THE MAIN BRANCH. 
